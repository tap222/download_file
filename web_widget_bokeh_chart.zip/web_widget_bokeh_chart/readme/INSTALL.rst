You need to install the python bokeh library::

    pip3 install bokeh==2.4.2
