* This module uses the library `Bokeh <https://github.com/bokeh/bokeh>`__
  which is under the open-source BSD 3-clause "New" or "Revised" License.
  Copyright (c) 2012, Anaconda, Inc.
* Odoo Community Association (OCA)
